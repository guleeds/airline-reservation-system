﻿using System;


namespace Registration_Module
{
    class Program
    {
        static string[] usernames = new string[100];
        static string[] passwords = new string[100];
        static int userCount = 0;

        static void Main(string[] args)
        {
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n=== Airline Registration System ===");
                Console.WriteLine("1. Register");
                Console.WriteLine("2. Login");
                Console.WriteLine("3. Exit");
                Console.Write("Select an option: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        RegisterUser();
                        break;
                    case "2":
                        LoginUser();
                        break;
                    case "3":
                        running = false;
                        Console.WriteLine("Goodbye!");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;

                }

            }
        }

        static void RegisterUser()
        {
            Console.WriteLine("\n--- User Registration ---");
            Console.Write("Enter username: ");
            string username = Console.ReadLine();

            for (int i = 0; i < userCount; i++)
            {
                if(usernames[i] == username)
                {
                    Console.WriteLine("Username already exists. Please try another.");
                    return;
                }
            }

            Console.Write("Enter password: ");
            string password = Console.ReadLine();

            usernames[userCount] = username;
            passwords[userCount] = password;
            userCount++;

            Console.WriteLine("Registration successful!");
        }

        static void LoginUser()
        {
            Console.WriteLine("\n--- Login ---");
            Console.Write("Enter username: ");
            string username = Console.ReadLine();

            Console.Write("Enter password: ");
            string password = Console.ReadLine();

            for (int i = 0; i < userCount; i++)
            {
                if (usernames[i] == username && passwords[i] == password)
                {
                    Console.WriteLine("Login successful! Welcome, " + username + ".");
                    return;
                }
            }
           
            Console.WriteLine("Login failed. Username or password is incorrect.");
            
        }

    }
}
   
