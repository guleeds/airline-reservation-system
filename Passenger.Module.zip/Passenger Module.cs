﻿using System;
using System.Collections.Generic;

namespace AirlineReservationSystem
{
    public class Program
    {
        static void Main(string[] args)
        {
            var flights = new List<Flight>
            {
                new Flight { FlightId = "FL001", Destination = "New York", DepartureTime = "10:00 AM", Fare = 250, AvailableSeats = 5 },
                new Flight { FlightId = "FL002", Destination = "Los Angeles", DepartureTime = "1:00 PM", Fare = 300, AvailableSeats = 3 },
                new Flight { FlightId = "FL003", Destination = "Chicago", DepartureTime = "5:00 PM", Fare = 200, AvailableSeats = 4 }
            };

            Passenger passenger = new Passenger { Username = "alec", Password = "1234" };

            int choice;
            do
            {
                Console.WriteLine("\n--- Passenger Menu ---");
                Console.WriteLine("1. View Flights");
                Console.WriteLine("2. Book Ticket");
                Console.WriteLine("3. View My Tickets");
                Console.WriteLine("4. Cancel Ticket");
                Console.WriteLine("5. Send Feedback");
                Console.WriteLine("6. Exit");
                Console.Write("Select option: ");
                string input = Console.ReadLine();
                if (!int.TryParse(input, out choice)) continue;

                switch (choice)
                {
                    case 1: passenger.ViewFlights(flights); break;
                    case 2: passenger.BookTicket(flights); break;
                    case 3: passenger.ViewTickets(); break;
                    case 4: passenger.CancelTicket(); break;
                    case 5: passenger.SendFeedback(); break;
                    case 6: Console.WriteLine("Exiting..."); break;
                    default: Console.WriteLine("Invalid choice."); break;
                }

            } while (choice != 6);
        }
    }

    public class Passenger
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public List<Ticket> BookedTickets { get; set; } = new List<Ticket>();

        public void ViewFlights(List<Flight> flights)
        {
            Console.WriteLine("\nAvailable Flights:");
            foreach (var flight in flights)
            {
                Console.WriteLine(flight);
            }
        }

        public void BookTicket(List<Flight> flights)
        {
            Console.Write("Enter Flight ID to book: ");
            string flightId = Console.ReadLine();

            var selectedFlight = flights.Find(f => f.FlightId.Equals(flightId, StringComparison.OrdinalIgnoreCase));
            if (selectedFlight != null && selectedFlight.AvailableSeats > 0)
            {
                selectedFlight.AvailableSeats--;
                var ticket = new Ticket
                {
                    Flight = selectedFlight,
                    PassengerName = this.Username,
                    TicketId = Guid.NewGuid().ToString().Substring(0, 8)
                };
                BookedTickets.Add(ticket);
                Console.WriteLine($"Ticket booked! Ticket ID: {ticket.TicketId}");
            }
            else
            {
                Console.WriteLine("Flight not found or no seats available.");
            }
        }

        public void ViewTickets()
        {
            if (BookedTickets.Count == 0)
            {
                Console.WriteLine("No tickets booked.");
                return;
            }

            Console.WriteLine("Your Tickets:");
            foreach (var ticket in BookedTickets)
            {
                Console.WriteLine(ticket);
            }
        }

        public void CancelTicket()
        {
            Console.Write("Enter Ticket ID to cancel: ");
            string ticketId = Console.ReadLine();

            var ticket = BookedTickets.Find(t => t.TicketId.Equals(ticketId, StringComparison.OrdinalIgnoreCase));
            if (ticket != null)
            {
                ticket.Flight.AvailableSeats++;
                BookedTickets.Remove(ticket);
                Console.WriteLine("Ticket canceled.");
            }
            else
            {
                Console.WriteLine("Ticket not found.");
            }
        }

        public void SendFeedback()
        {
            Console.Write("Enter your feedback: ");
            string feedback = Console.ReadLine();
            Console.WriteLine("Thank you for your feedback!");
            // Feedback could be saved to file/database in a real app
        }
    }

    public class Flight
    {
        public string FlightId { get; set; }
        public string Destination { get; set; }
        public string DepartureTime { get; set; }
        public double Fare { get; set; }
        public int AvailableSeats { get; set; }

        public override string ToString()
        {
            return $"FlightID: {FlightId}, To: {Destination}, Time: {DepartureTime}, Fare: ${Fare}, Seats: {AvailableSeats}";
        }
    }

    public class Ticket
    {
        public string TicketId { get; set; }
        public string PassengerName { get; set; }
        public Flight Flight { get; set; }

        public override string ToString()
        {
            return $"TicketID: {TicketId}, Passenger: {PassengerName}, Flight to {Flight.Destination} at {Flight.DepartureTime}";
        }
    }
}