﻿using System;

namespace AirlineReservationSystem
{
    class Program
    {
        // Users
        static string[] usernames = new string[100];
        static string[] passwords = new string[100];
        static string[] roles = new string[100];
        static int userCount = 0;

        // Flights
        static string[] flightNumbers = new string[50];
        static string[] sources = new string[50];
        static string[] destinations = new string[50];
        static string[] dates = new string[50];
        static string[] times = new string[50];
        static double[] fares = new double[50];
        static int[] availableSeats = new int[50];
        static int[] totalSeats = new int[50];
        static int flightCount = 0;

        // Bookings
        static string[] bookingUsernames = new string[200];
        static string[] bookingFlightNumbers = new string[200];
        static int bookingCount = 0;

        static void Main(string[] args)
        {
            SeedAdminAccount();
            AdminMenu();
        }

        static void SeedAdminAccount()
        {
            usernames[userCount] = "admin";
            passwords[userCount] = "admin";
            roles[userCount] = "admin";
            userCount++;
        }

        static void AdminMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("===== ADMIN PANEL =====");
                Console.WriteLine("1. Add Flight");
                Console.WriteLine("2. View All Flights");
                Console.WriteLine("3. View Passenger List");
                Console.WriteLine("4. Update Flight");
                Console.WriteLine("5. Cancel Passenger Ticket");
                Console.WriteLine("6. Exit");
                Console.Write("Select option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddFlight();
                        break;
                    case "2":
                        ViewFlights();
                        break;
                    case "3":
                        ViewPassengerList();
                        break;
                    case "4":
                        UpdateFlight();
                        break;
                    case "5":
                        CancelPassengerTicket();
                        break;
                    case "6":
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Press Enter...");
                        Console.ReadLine();
                        break;
                }
            }
        }

        static void AddFlight()
        {
            Console.Clear();
            Console.WriteLine("===== Add New Flight =====");
            Console.Write("Flight Number: ");
            flightNumbers[flightCount] = Console.ReadLine();
            Console.Write("Source: ");
            sources[flightCount] = Console.ReadLine();
            Console.Write("Destination: ");
            destinations[flightCount] = Console.ReadLine();
            Console.Write("Date (MM/DD/YYYY): ");
            dates[flightCount] = Console.ReadLine();
            Console.Write("Time (HH:MM): ");
            times[flightCount] = Console.ReadLine();
            Console.Write("Fare: ");
            fares[flightCount] = double.Parse(Console.ReadLine());
            Console.Write("Total Seats: ");
            int seats = int.Parse(Console.ReadLine());
            totalSeats[flightCount] = seats;
            availableSeats[flightCount] = seats;

            flightCount++;
            Console.WriteLine("Flight added successfully! Press Enter...");
            Console.ReadLine();
        }

        static void ViewFlights()
        {
            Console.Clear();
            Console.WriteLine("===== All Flights =====");
            for (int i = 0; i < flightCount; i++)
            {
                Console.WriteLine($"{i + 1}. {flightNumbers[i]} | {sources[i]} -> {destinations[i]} | {dates[i]} {times[i]} | Fare: ${fares[i]} | Seats: {availableSeats[i]}/{totalSeats[i]}");
            }
            Console.WriteLine("Press Enter to continue...");
            Console.ReadLine();
        }

        static void ViewPassengerList()
        {
            Console.Clear();
            Console.WriteLine("===== Passenger Bookings =====");
            for (int i = 0; i < bookingCount; i++)
            {
                if (bookingUsernames[i] != "cancelled")
                {
                    Console.WriteLine($"{bookingUsernames[i]} → Flight: {bookingFlightNumbers[i]}");
                }
            }
            Console.WriteLine("Press Enter to continue...");
            Console.ReadLine();
        }

        static void UpdateFlight()
        {
            ViewFlights();
            Console.Write("Enter Flight Number to Update: ");
            string flightNo = Console.ReadLine();

            for (int i = 0; i < flightCount; i++)
            {
                if (flightNumbers[i] == flightNo)
                {
                    Console.WriteLine("1. Update Time");
                    Console.WriteLine("2. Update Fare");
                    Console.Write("Choose option: ");
                    string option = Console.ReadLine();

                    if (option == "1")
                    {
                        Console.Write("New Time (HH:MM): ");
                        times[i] = Console.ReadLine();
                        Console.WriteLine("Flight time updated.");
                    }
                    else if (option == "2")
                    {
                        Console.Write("New Fare: ");
                        fares[i] = double.Parse(Console.ReadLine());
                        Console.WriteLine("Flight fare updated.");
                    }
                    else
                    {
                        Console.WriteLine("Invalid option.");
                    }

                    Console.WriteLine("Press Enter...");
                    Console.ReadLine();
                    return;
                }
            }

            Console.WriteLine("Flight not found. Press Enter...");
            Console.ReadLine();
        }

        static void CancelPassengerTicket()
        {
            Console.Clear();
            Console.WriteLine("===== Cancel Ticket =====");
            Console.Write("Passenger Username: ");
            string user = Console.ReadLine();
            Console.Write("Flight Number: ");
            string flightNo = Console.ReadLine();

            for (int i = 0; i < bookingCount; i++)
            {
                if (bookingUsernames[i] == user && bookingFlightNumbers[i] == flightNo)
                {
                    bookingUsernames[i] = "cancelled";
                    bookingFlightNumbers[i] = "cancelled";

                    for (int j = 0; j < flightCount; j++)
                    {
                        if (flightNumbers[j] == flightNo)
                        {
                            availableSeats[j]++;
                            break;
                        }
                    }

                    Console.WriteLine("Ticket cancelled. Press Enter...");
                    Console.ReadLine();
                    return;
                }
            }

            Console.WriteLine("Booking not found. Press Enter...");
            Console.ReadLine();
        }
    }
}

