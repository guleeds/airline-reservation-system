﻿using System;

namespace AirlineReservationSystem
{
    class Program
    {
        // Users
        static string[] usernames = new string[100];
        static string[] passwords = new string[100];
        static string[] roles = new string[100];
        static int userCount = 0;

        // Flights
        static string[] flightNumbers = new string[50];
        static string[] sources = new string[50];
        static string[] destinations = new string[50];
        static string[] dates = new string[50];
        static string[] times = new string[50];
        static double[] fares = new double[50];
        static int[] availableSeats = new int[50];
        static int[] totalSeats = new int[50];
        static int flightCount = 0;

        // Bookings
        static string[] bookingUsernames = new string[200];
        static string[] bookingFlightNumbers = new string[200];
        static int bookingCount = 0;

        static void Main(string[] args)
        {
            SeedAdminAccount();
            SeedTestData();
            AdminMenu();
        }

        static void SeedAdminAccount()
        {
            usernames[userCount] = "admin";
            passwords[userCount] = "admin";
            roles[userCount] = "admin";
            userCount++;
        }

        static void SeedTestData()
        {
            // One test flight
            flightNumbers[0] = "AA123";
            sources[0] = "Charlotte";
            destinations[0] = "New York";
            dates[0] = "05/10/2025";
            times[0] = "09:30 AM";
            fares[0] = 150.00;
            totalSeats[0] = 100;
            availableSeats[0] = 99;
            flightCount++;

            // One test booking
            bookingUsernames[0] = "guleed";
            bookingFlightNumbers[0] = "AA123";
            bookingCount++;
        }

        static void AdminMenu()
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("===== ADMIN PANEL =====");
                Console.WriteLine("1. Add Flight");
                Console.WriteLine("2. View All Flights");
                Console.WriteLine("3. View Passenger List");
                Console.WriteLine("4. Update Flight");
                Console.WriteLine("5. Cancel Passenger Ticket");
                Console.WriteLine("6. Exit");
                Console.Write("Select option: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddFlight();
                        break;
                    case "2":
                        ViewFlights();
                        break;
                    case "3":
                        ViewPassengerList();
                        break;
                    case "4":
                        UpdateFlight();
                        break;
                    case "5":
                        CancelPassengerTicket();
                        break;
                    case "6":
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Press Enter...");
                        Console.ReadLine();
                        break;
                }
            }
        }

        static void AddFlight()
        {
            Console.Clear();
            Console.WriteLine("===== Add New Flight =====");
            Console.Write("Flight Number: ");
            flightNumbers[flightCount] = Console.ReadLine();
            Console.Write("Source: ");
            sources[flightCount] = Console.ReadLine();
            Console.Write("Destination: ");
            destinations[flightCount] = Console.ReadLine();
            Console.Write("Date (MM/DD/YYYY): ");
            dates[flightCount] = Console.ReadLine();
            Console.Write("Time (HH:MM AM/PM): ");
            times[flightCount] = Console.ReadLine();
            Console.Write("Fare: ");
            fares[flightCount] = double.Parse(Console.ReadLine());
            Console.Write("Total Seats: ");
            int seats = int.Parse(Console.ReadLine());
            totalSeats[flightCount] = seats;
            availableSeats[flightCount] = seats;

            flightCount++;
            Console.WriteLine("Flight added successfully! Press Enter...");
            Console.ReadLine();
        }

        static void ViewFlights()
        {
            Console.Clear();
            Console.WriteLine("===== All Flights =====");
            for (int i = 0; i < flightCount; i++)
            {
                Console.WriteLine($"{i + 1}. {flightNumbers[i]} | {sources[i]} → {destinations[i]} | {dates[i]} {times[i]} | Fare: ${fares[i]} | Seats: {availableSeats[i]}/{totalSeats[i]}");
            }
            Console.WriteLine("Press Enter to continue...");
            Console.ReadLine();
        }

        static void ViewPassengerList()
        {
            Console.Clear();
            Console.WriteLine("===== Passenger Bookings =====");
            bool found = false;
            for (int i = 0; i < bookingCount; i++)
            {
                if (bookingUsernames[i] != "cancelled")
                {
                    Console.WriteLine($"{bookingUsernames[i]} → Flight: {bookingFlightNumbers[i]}");
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine("No passenger bookings found.");
            }

            Console.WriteLine("Press Enter to continue...");
            Console.ReadLine();
        }

        static void UpdateFlight()
        {
            Console.Clear();
            ViewFlights();
            Console.Write("Enter Flight Number to Update: ");
            string flightNo = Console.ReadLine();

            for (int i = 0; i < flightCount; i++)
            {
                if (flightNumbers[i] == flightNo)
                {
                    Console.WriteLine($"\nCurrent Details:");
                    Console.WriteLine($"Source: {sources[i]}");
                    Console.WriteLine($"Destination: {destinations[i]}");
                    Console.WriteLine($"Date: {dates[i]}");
                    Console.WriteLine($"Time: {times[i]}");
                    Console.WriteLine($"Fare: ${fares[i]}");

                    Console.WriteLine("\nWhat would you like to update?");
                    Console.WriteLine("1. Time");
                    Console.WriteLine("2. Fare");
                    Console.WriteLine("3. Date");
                    Console.WriteLine("4. Source");
                    Console.WriteLine("5. Destination");
                    Console.Write("Choose option (1–5): ");
                    string option = Console.ReadLine();

                    switch (option)
                    {
                        case "1":
                            Console.Write("New Time (HH:MM AM/PM): ");
                            times[i] = Console.ReadLine();
                            Console.WriteLine("Flight time updated.");
                            break;
                        case "2":
                            Console.Write("New Fare: ");
                            fares[i] = double.Parse(Console.ReadLine());
                            Console.WriteLine("Flight fare updated.");
                            break;
                        case "3":
                            Console.Write("New Date (MM/DD/YYYY): ");
                            dates[i] = Console.ReadLine();
                            Console.WriteLine("Flight date updated.");
                            break;
                        case "4":
                            Console.Write("New Source: ");
                            sources[i] = Console.ReadLine();
                            Console.WriteLine("Flight source updated.");
                            break;
                        case "5":
                            Console.Write("New Destination: ");
                            destinations[i] = Console.ReadLine();
                            Console.WriteLine("Flight destination updated.");
                            break;
                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }

                    Console.WriteLine("Update complete. Press Enter...");
                    Console.ReadLine();
                    return;
                }
            }

            Console.WriteLine("Flight not found. Press Enter...");
            Console.ReadLine();
        }

        static void CancelPassengerTicket()
        {
            Console.Clear();
            Console.WriteLine("===== Cancel Passenger Ticket =====");
            Console.Write("Passenger Username: ");
            string user = Console.ReadLine();
            Console.Write("Flight Number: ");
            string flightNo = Console.ReadLine();

            for (int i = 0; i < bookingCount; i++)
            {
                if (bookingUsernames[i] == user && bookingFlightNumbers[i] == flightNo)
                {
                    bookingUsernames[i] = "cancelled";
                    bookingFlightNumbers[i] = "cancelled";

                    for (int j = 0; j < flightCount; j++)
                    {
                        if (flightNumbers[j] == flightNo)
                        {
                            availableSeats[j]++;
                            break;
                        }
                    }

                    Console.WriteLine("Ticket cancelled successfully. Press Enter...");
                    Console.ReadLine();
                    return;
                }
            }

            Console.WriteLine("Booking not found. Press Enter...");
            Console.ReadLine();
        }
    }
}



